﻿using PlantMapping = Database.MappingTypes.PlantMapping;

namespace Database.DatabaseStructure.Repository.Abstract
{
    public interface IPlantMappingRepository : IRepository<PlantMapping>
    { }
}