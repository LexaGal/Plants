using Database.MappingTypes;

namespace Database.DatabaseStructure.Repository.Abstract
{
    public interface IServiceScheduleMappingRepository : IRepository<ServiceScheduleMapping>
    {
    }
}