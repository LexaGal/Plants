﻿using PlantsAreaMapping = Database.MappingTypes.PlantsAreaMapping;

namespace Database.DatabaseStructure.Repository.Abstract
{
    public interface IPlantsAreaMappingRepository : IRepository<PlantsAreaMapping>
    {}
}