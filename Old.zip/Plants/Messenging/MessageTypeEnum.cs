namespace PlantingLib.Messenging
{
    public enum MessageTypeEnum
    {
        UsualInfo,
        CriticalInfo
    }
}