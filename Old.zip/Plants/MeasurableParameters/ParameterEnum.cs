﻿namespace PlantingLib.MeasurableParameters
{
    public enum ParameterEnum
    {
        Nutrient,
        SoilPh,
        Humidity,
        Temperature
    }
}