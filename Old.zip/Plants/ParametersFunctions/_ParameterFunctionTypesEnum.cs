﻿namespace Planting.ParametersFunctions
{
    public enum ParameterFunctionTypesEnum
    {
        Increasing,
        Decreasing,
        Constant 
    }
}
