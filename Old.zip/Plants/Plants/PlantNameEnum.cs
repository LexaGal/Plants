﻿namespace PlantingLib.Plants
{
    public enum PlantNameEnum
    {
        Apple,
        Pear,
        Carrot,
        Tomato,
        Potato,
        Nut,
        Cucumber,
        Scallion,
        Radish,
        Strawberry,
        Raspberry
    }
}