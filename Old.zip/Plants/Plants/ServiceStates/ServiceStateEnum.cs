namespace PlantingLib.Plants.ServiceStates
{
    public enum ServiceStateEnum
    {
        Nutrienting,
        Watering,
        Warming,
        Cooling
    }
}