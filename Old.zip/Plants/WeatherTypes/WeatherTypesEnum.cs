﻿namespace PlantingLib.WeatherTypes
{
    public enum WeatherTypesEnum
    {
        Cold,
        Warm,
        Hot,
        Rainy
    }
}